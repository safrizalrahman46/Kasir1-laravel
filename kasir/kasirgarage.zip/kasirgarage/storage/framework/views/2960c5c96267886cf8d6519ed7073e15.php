<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" >
        <div class="">
            <i class="fa fa-fw fa-home"></i>
        </div>
        <div class="sidebar-brand-text mx-3">Data Siswa <sup></sup></div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <div class="sidebar-heading">
        Menu Sidebar
    </div>

    <!-- Nav Item - Dashboard -->
    <li class="nav-item active">
        <a class="nav-link " href="<?php echo e(url('/halamanutama')); ?>">
            <i class="fas fa-globe-europe"></i>
            <span>Beranda</span></a>
    </li>
    <li class="nav-item active">
        <a class="nav-link" href="<?php echo e(url('/siswa')); ?>">
            <i class="fa fa-user-circle-o"></i>
            <span>Data Siswa</span></a>
    </li>
    <li class="nav-item active">
        <a class="nav-link" href="<?php echo e(url('/siswa/create')); ?>">
            <i class="fa fa-user-circle-o"></i>
            <span>Input Data Siswa</span></a>
    </li>
    <li class="nav-item active">
        <a class="nav-link" href="<?php echo e(url('/guru')); ?>">
            <i class="fa fa-user-circle-o"></i>
            <span>Data Tabel Guru</span></a>
    </li>
    <li class="nav-item active">
        <a class="nav-link" href="<?php echo e(url('/siswa/guru')); ?>">
            <i class="fa fa-user-circle-o"></i>
            <span>Data Guru</span></a>
    </li>
    <li class="nav-item active">
        <a class="nav-link" href="<?php echo e(url('/guru/create')); ?>">
            <i class="fa fa-user-circle-o"></i>
            <span>Input Data Guru</span></a>
    </li>
    <li class="nav-item active">
        <a class="nav-link" href="<?php echo e(url('/guru/mapel')); ?>">
            <i class="fa fa-user-circle-o"></i>
            <span>Data Mapel</span></a>
    </li>
    <li class="nav-item active">
        <a class="nav-link" href="<?php echo e(url('/mapel')); ?>">
            <i class="fa fa-user-circle-o"></i>
            <span>Data Tabel Mapel</span></a>
    </li>
    <li class="nav-item active">
        <a class="nav-link" href="<?php echo e(url('/mapel/create')); ?>">
            <i class="fa fa-user-circle-o"></i>
            <span>Input Data Mapel</span></a>
    </li>
    <li class="nav-item active">
        <a class="nav-link" href="<?php echo e(url('/nilai')); ?>">
            <i class="fa fa-user-circle-o"></i>
            <span>Nilai</span></a>
    </li>
    <li class="nav-item active">
        <a class="nav-link" href="<?php echo e(url('/nilai/create')); ?>">
            <i class="fa fa-user-circle-o"></i>
            <span>Input Nilai Siswa</span></a>
    </li>

    <!-- Divider -->
    

    <!-- Heading -->


    <!-- Nav Item - Pages Collapse Menu -->
    <li class="nav-item">

        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            
        </div>
    </li>

    <!-- Nav Item - Utilities Collapse Menu -->
    
            <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities"
                data-parent="#accordionSidebar">
                
        </div>
    </li>

    <!-- Divider -->
    

    <!-- Heading -->
    

    <!-- Nav Item - Pages Collapse Menu -->
    <li class="nav-item">
        
        <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
            
        </div>
    </li>

    <!-- Nav Item - Charts -->
    

    <!-- Nav Item - Tables -->
    

    <!-- Divider -->
    <hr class="sidebar-divider d-none d-md-block">

    <!-- Sidebar Toggler (Sidebar) -->
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>

    <!-- Sidebar Message -->
    

</ul>
<?php /**PATH C:\laragon\www\kasirgarage\resources\views/layout/include/sidebar.blade.php ENDPATH**/ ?>