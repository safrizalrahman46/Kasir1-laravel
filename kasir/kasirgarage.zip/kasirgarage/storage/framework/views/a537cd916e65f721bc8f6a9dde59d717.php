<?php $__env->startSection('content'); ?>
<div class="content">
<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Nilai</h1>
    </div>
    <div class="row">
<div class="container-fluid">


    <!-- Page Heading -->
    

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Nilai Siswa</h6>
        </div>
        <div class="card-body">

            <form action="/nilai/search" class="form-inline" method="GET">
                <div class="table-responsive">
                    <div class="input-group">
                        <input name="search" type="search" class="form-control bg-light border-0 small" placeholder="Search for..." >
                        <div class="input-group-append">
                            <button class="btn btn-primary" type="button">
                                <i class="fas fa-search fa-sm"></i>
                            </button>
                        </div>
                    </div>
                </form>

            
                <div id="dataTable_wrapper" class="dataTables_wrapper dt-bootstrap4"><div class="row">
                    
                            
                        </div>
                        </div>
                            <div class="row">
                                <div class="col-sm-12"><table class="table table-bordered dataTable" id="dataTable" width="100%" cellspacing="0" role="grid" aria-describedby="dataTable_info" style="width: 100%;">
                    <thead>
                        <tr role="row"><th name="siswa_id" class="sorting sorting_asc" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 195.2px;">Siswa</th>
                        <th name="mapel_id" class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" aria-label="Position: activate to sort column ascending" style="width: 296.2px;">Mapel</th>
                        <th name="nilai" class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" aria-label="Position: activate to sort column ascending" style="width: 296.2px;">Nilai</th>
                        <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" aria-label="Position: activate to sort column ascending" style="width: 296.2px;">Opsi</th>

                    </thead>
                    <tfoot>
                        
                    </tfoot>
                    <tbody>
                        <?php $__currentLoopData = $nilais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nilai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($nilai->siswa_id ? $nilai->siswa->nama : 'Tidak Punya Siswa'); ?> </td>

                            

                            <td><?php echo e($nilai->mapel_id ? $nilai->mapel->nama_mapel : 'Tidak Punya Mapel'); ?> </td>
                            <td><?php echo e($nilai->nilai); ?> </td>
                            <td> <a href="/nilai/<?php echo e($nilai->id); ?>/delete" class="btn btn-danger" onclick="return confirm('APAKAH ANDA YAKIN? <?php echo e($nilai->nama); ?>');">HAPUS</a>
                                <a  href="/nilai/<?php echo e($nilai->id); ?>/edit" class="btn btn-warning">Edit</a>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </tbody>
                   
                
            </div>
        </div>
    </div>

</div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kasirgarage\resources\views/admin/nilai/index.blade.php ENDPATH**/ ?>