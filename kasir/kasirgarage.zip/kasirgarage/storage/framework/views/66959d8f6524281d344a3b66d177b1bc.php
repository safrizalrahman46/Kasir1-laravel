<?php $__env->startSection('content'); ?>

<div class="container-fluid">

<div class="card mb-3">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Form inputan</h6>
    </div>
    <div class="container-fluid">

        
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(url('/guru/store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <br>
        <div class="mb-2">
          <label for="nama" class="form-label">Nama</label>
          <input type="text" class="form-control" id="exampleInputEmail1" name="nama" placeholder="nama" >
        </div>

        <div class="mb-2">
          <label for="nip" class="form-label">NIP Guru</label>
          <input type="number" class="form-control" id="exampleInputEmail1" name="nip" placeholder="nip" >
        </div>

        




            <br>
        <button type="submit" class="btn btn-primary">Submit</button>
        <hr>
      </form>
    </div>
</div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kasirgarage\resources\views/admin/guru/create.blade.php ENDPATH**/ ?>