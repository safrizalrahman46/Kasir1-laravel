<?php $__env->startSection('content'); ?>

<div class="container-fluid">

<div class="card mb-3">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Form inputan</h6>
    </div>
    <div class="container-fluid">

        
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(url('/nilai/store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <br>
        <div class="mb-2">
          <label for="siswa_id" class="form-label">Nama Siswa </label>
          
          <select  name="siswa_id" id="" class="custom-select rounded-0">
            <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </optgroup>

        </div>

        <div class="form-select mb-2">
            <label for="mapel_id" class="form-label">Mapel Siswa</label>
              <select  name="mapel_id" id="" class="custom-select rounded-0">
                <?php $__currentLoopData = $mapel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($pel->id); ?>"><?php echo e($pel->nama_mapel); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </optgroup>

            </select>
            </div>

        

        <div class="mb-2">
          <label for="nilai" class="form-label">Nilai Siswa</label>
          <input type="number" class="form-control" id="exampleInputEmail1" name="nilai" placeholder="nilai" >
        </div>



        




            <br>
        <button type="submit" class="btn btn-primary">Submit</button>
        <hr>
      </form>
    </div>
</div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kasirgarage\resources\views/admin/nilai/create.blade.php ENDPATH**/ ?>