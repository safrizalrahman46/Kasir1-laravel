<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; Safrizal Rahman 2023</span>
        </div>
    </div>
</footer>
<?php /**PATH C:\laragon\www\kasirgarage\resources\views/layout/include/footer.blade.php ENDPATH**/ ?>