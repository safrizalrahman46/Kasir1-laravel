<?php $__env->startSection('content'); ?>
<div class="container-fluid">
<div class="card mb-3">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Edit inputan</h6>
    </div>
    <div class="container-fluid">

        
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="/siswa/<?php echo e($siswa->id); ?>/update" method="POST">
        <?php echo csrf_field(); ?>
        <br>
        <div class="mb-2">
          <label for="nama" class="form-label">Nama</label>
          <input type="text" class="form-control" id="exampleInputEmail1" name="nama" placeholder="nama" value="<?php echo e($siswa->nama); ?>">
        </div>

        <div class="form-select mb-2">
        <label for="jenkel" class="form-label">Jenis Kelamin Siswa</label>
          <select name="jenkel" id="" class="custom-select rounded-0">
            <option selected="">Pilih Jenis Kelamin</option>
            <option value="Pria" <?php if($siswa->jenkel=='Pria'): ?> selected <?php endif; ?>>Pria</option>
            <option value="Wanita"<?php if($siswa->jenkel=='Wanita'): ?> selected <?php endif; ?>>Wanita</option>
        </select>

        </div>

        <div class="form-label">
            <label for="alamat" class="form-label" >Alamat</label>
          <input name="alamat" placeholder="alamat" value="<?php echo e($siswa->alamat); ?>" type="text" class="form-control" id="exampleInputEmail1" >
        </div>

        <div class="form-group">
            <label for="nohp" class="form-label">No Hp Siswa</label>
          <input name="nohp" type="number" value="<?php echo e($siswa->nohp); ?>" placeholder="+62" class="form-control" id="exampleInputEmail1" >
        </div>

        <div class="mb-2">
          <label for="email" class="form-label">Email Siswa</label>
          <input name="email" type="email" value="<?php echo e($siswa->email); ?>" placeholder="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
        </div>

        <div class="form-select mb-2">
            <label for="jurusan" class="form-label">Jurusan Siswa</label>
              <select name="jurusan" id="" class="custom-select rounded-0">
                <option selected="">Pilih Jurusan</option>
                <option value="Multimedia" <?php if($siswa->jurusan=='Multimedia'): ?> selected <?php endif; ?>>Multimedia</option>
                <option value="Rpl" <?php if($siswa->jurusan=='Rpl'): ?> selected <?php endif; ?>>Rpl </option>
                <option value="Tkj" <?php if($siswa->jurusan=='Tkj'): ?> selected <?php endif; ?>>Tkj  </option>
                <option value="Listrik" <?php if($siswa->jurusan=='Listrik'): ?> selected <?php endif; ?>>Listrik</option>
            </select>
            </div>

            <br>
        <button type="submit" class="btn btn-warning">Update</button>
        <hr>
      </form>
    </div>
</div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kasirgarage\resources\views/admin/siswa/edit.blade.php ENDPATH**/ ?>