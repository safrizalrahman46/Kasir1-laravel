<?php $__env->startSection('content'); ?>
<div class="container-fluid">
<div class="card mb-3">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Edit inputan</h6>
    </div>
    <div class="container-fluid">

        
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="/mapel/<?php echo e($mapel->id); ?>/update" method="POST">
        <?php echo csrf_field(); ?>
        <br>
        
        <div class="form-label">
            <label for="nama_mapel" class="form-label" >Nama Mapel</label>
          
          
          <select  name="nama_mapel" id="" class="custom-select rounded-0">
          <?php $__currentLoopData = $allMapel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          
            <option value="<?php echo e($mp->nama_mapel); ?>"  <?php if($mp->id == $mapel->id): echo 'selected'; endif; ?> ><?php echo e($mp->nama_mapel); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>

        <div class="form-label">
            <label for="kode_mapel" class="form-label" >Kode Mapel</label>
          <input type="number" name="kode_mapel" placeholder="kode_mapel" value="<?php echo e($mapel->kode_mapel); ?>" class="form-control" id="exampleInputEmail1" >
        </div>

            <div class="form-select mb-2">
                <label for="guru_id" class="form-label">Guru Pengajar</label>
                
                  <select  name="guru_id" id="" class="custom-select rounded-0">
                    
                    <?php $__currentLoopData = $guru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($gr->id); ?>"  <?php if($gr->id == $mapel->guru->id): echo 'selected'; endif; ?> ><?php echo e($gr->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </optgroup>

                </select>
                </div>

        

        



            <br>
        <button type="submit" class="btn btn-warning">Update</button>
        <hr>
      </form>
    </div>
</div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kasirgarage\resources\views/admin/mapel/edit.blade.php ENDPATH**/ ?>