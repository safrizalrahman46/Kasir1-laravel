<?php $__env->startSection('content'); ?>
<div class="container-fluid">
<div class="card mb-3">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Edit inputan</h6>
    </div>
    <div class="container-fluid">

        
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="/guru/<?php echo e($guru->id); ?>/update" method="POST">
        <?php echo csrf_field(); ?>
        <br>
        <div class="mb-2">
          <label for="nama" class="form-label">Nama</label>
          <input type="text" class="form-control" id="exampleInputEmail1" name="nama" placeholder="nama" value="<?php echo e($guru->nama); ?>">
        </div>

        <div class="form-label">
            <label for="nip" class="form-label" >Nip Guru</label>
          <input name="nip" placeholder="nip" value="<?php echo e($guru->nip); ?>" type="text" class="form-control" id="exampleInputEmail1" >
        </div>

            <br>
        <button type="submit" class="btn btn-warning">Update</button>
        <hr>
      </form>
    </div>
</div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kasirgarage\resources\views/admin/guru/edit.blade.php ENDPATH**/ ?>